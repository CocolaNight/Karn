<div class="container-fluid p-4">
    <div class="container-sm m-auto p-4 pt-0">
        <div class="container-fluid p-4  bg-" data-aos="zoom-in">
            <div class="d-flex mb-2">
           
                </div>
            </div>
            <div class="container-fluid mt-2 mb-5 p-4">
                <div class="container-sm p-0">
                    <div class="row justify-content-center">
                        <div class="col-lg-3">
                            <div class="container-fluid bg-glass p-4 pt-5 rounded border shadow-sm">
                                <center>
                                    <img src="assets/icon/voucher.png" class="img-fluid mb-3" style="height: 100px;">
                                    <h2 class="text-main mb-0">ซองอั่งเปา</h2>
                                    <small class="text-black">เติมเงินผ่านซองอั่งเปา TrueWallet</small>
                                    <a href="?page=angpao" class="btn bg-main w-100 mt-2 text-white">เติมเงิน</a>
                                </center>
                            </div>
                        </div>
                        <div class="col-lg-3">
                            <div class="container-fluid bg-glass p-4 pt-5 rounded border shadow-sm">
                                <center>
                                    <img src="assets/icon/gift-card.png" class="img-fluid mb-3" style="height: 100px;">
                                    <h2 class="text-main mb-0">กรอกโค้ด</h2>
                                    <small class="text-black">กรอกโค้ดรับเงินจากร้านค้า</small>
                                    <a href="?page=redeem" class="btn bg-main w-100 mt-2 text-white">เติมโค้ด</a>
                                </center>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>